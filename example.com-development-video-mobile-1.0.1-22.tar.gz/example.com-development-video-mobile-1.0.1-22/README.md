This is an example of a deploy for Docker within the cluster environment
of AWS and utilizing Artifactory as a store.
